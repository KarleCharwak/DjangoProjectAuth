from django.contrib import admin
from .models import Country, City, Student, Course, Enrollment, Grade

@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ['name']

@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = ['name', 'country']

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['name', 'city', 'address', 'date_of_birth', 'gender', 'phone_number', 'email', 'branch']
    list_filter = ['city', 'gender']
    search_fields = ['name', 'email']

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'credits']
    search_fields = ['name']

@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ['student_name', 'course', 'enrollment_date']
    list_filter = ['course']
    search_fields = ['student_name']

@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ['enrollment', 'grade']
    list_filter = ['grade']
    search_fields = ['enrollment__student_name']

