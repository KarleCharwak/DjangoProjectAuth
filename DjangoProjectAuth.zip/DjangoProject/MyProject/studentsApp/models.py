from django.db import models

class Country(models.Model):
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class City(models.Model):
    name = models.CharField(max_length=300)
    country = models.ForeignKey(Country, on_delete=models.CASCADE)

    def __str__(self):
        return self.name
    
class Student(models.Model):
    name = models.CharField(max_length=150)  # Assuming maximum length for the name
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    address = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=10, choices=(('M', 'Male'), ('F', 'Female')))
    phone_number = models.CharField(max_length=15)
    email = models.EmailField()
    branch = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class Course(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    credits = models.DecimalField(max_digits=5, decimal_places=2)
    # Add more fields as needed

    def __str__(self):
        return self.name

class Enrollment(models.Model):
    student_name = models.CharField(max_length=150)  # Update to store student's name directly
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    enrollment_date = models.DateField()

    def __str__(self):
        return f"{self.student_name} enrolled in {self.course}"

class Grade(models.Model):
    enrollment = models.ForeignKey(Enrollment, on_delete=models.CASCADE)
    grade = models.DecimalField(max_digits=5, decimal_places=2)
    # Add more fields as needed

    def __str__(self):
        return f"Grade {self.grade} for {self.enrollment}"
    

# models.py


