from django.shortcuts import render,redirect
from studentsApp.models import Student, City,Course, Enrollment, Grade
import csv
from django.http import HttpResponse
from django.http import FileResponse
import io
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .forms import StudentForm





import io
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from django.http import HttpResponse
from .models import Student

def student_pdf(request):
    # Create Bytestream buffer
    buf = io.BytesIO()
    # Create a Canvas
    c = canvas.Canvas(buf, pagesize=letter, bottomup=0)
    # Create a text object
    textob = c.beginText(inch, inch)
    textob.setFont("Helvetica", 14)

    # Add some lines of text
    students = Student.objects.all()
    lines = []
    for student in students:
        lines.append("==========================")
        lines.append(student.name)
        lines.append(student.city.name)
        lines.append(student.address)
        lines.append(str(student.date_of_birth))  # Convert date to string
        lines.append(student.gender)
        lines.append(student.phone_number)
        lines.append(student.email)
        lines.append(student.branch)
        lines.append("==========================")

    max_lines_per_page = 30  # Adjust this based on the number of lines that fit on a page

    for i, line in enumerate(lines):
        if i > 0 and i % max_lines_per_page == 0:
            # Start a new page
            c.drawText(textob)
            c.showPage()
            textob = c.beginText(inch, inch)
            textob.setFont("Helvetica", 14)

        textob.textLine(line)

    # Draw any remaining content on the last page
    c.drawText(textob)
    c.showPage()

    # Close the canvas
    c.save()

    # Set response headers
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="student_info.pdf"'
    response.write(buf.getvalue())
    buf.close()

    return response


def student_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition']='attachment; filename=students.csv'
    # Create a Csv writer
    writer = csv.writer(response)

    students = Student.objects.all()
    writer.writerow(['Name','Address','Branch'])

    for student in students:
        writer.writerow([student.user.get_full_name(), student.address, student.branch])
    return response

def student_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=students.csv'
    
    writer = csv.writer(response)
    writer.writerow(['Name', 'City', 'Address', 'Date of Birth', 'Gender', 'Phone Number', 'Email', 'Branch'])
    
    students = Student.objects.all()
    for student in students:
        writer.writerow([
            student.name,
            student.city.name if student.city else '',
            student.address,
            student.date_of_birth,
            student.gender,
            student.phone_number,
            student.email,
            student.branch
        ])
    
    return response

def view_student(request):
    students = Student.objects.all()
    cities = City.objects.all()
    return render(request, 'student.html', {'students': students, 'cities': cities})

def view_django(request):
    return render(request, 'django.html', {})

def view_hello(request):
    return render(request, 'hello.html', {})

def view_about(request):
    return render(request, 'about.html', {})

def add(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('record')
    else:
        form = StudentForm()
    return render(request, 'Add.html', {'form': form})


def view_record(request):
    students = Student.objects.all()  # Query all students
    return render(request, 'record.html', {'students': students})


# def login_view(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             login(request, user)
#             return redirect('record')  # Redirect to the home page after successful login
#         else:
#             messages.error(request, 'Invalid username or password')
#     return render(request, 'login.html')

# def view_login(request):
#     return render(request, 'login.html', {})

# def dashboard(request):
#     return render(request,'dashboard.html')

def dashboard(request):
    total_students = Student.objects.count()
    total_courses = Course.objects.count()
    total_enrollments = Enrollment.objects.count()
    total_grades = Grade.objects.count()

    context = {
        'total_students': total_students,
        'total_courses': total_courses,
        'total_enrollments': total_enrollments,
        'total_grades': total_grades
    }

    return render(request, 'dashboard.html', context)
