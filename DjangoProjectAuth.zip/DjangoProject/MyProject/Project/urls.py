from django.contrib import admin
from django.urls import path,include
# from studentsApp.views import login_view
from studentsApp.views import view_hello, view_record, view_about, student_pdf, student_csv,dashboard,add

urlpatterns = [
    path('admin/', admin.site.urls),
    path('hello/', view_hello, name='hello'),
    path('about/', view_about, name='about'),
    path('add/', add, name='add'),
    path('record/', view_record, name='record'),
    path('dashboard/', dashboard, name='dashboard'),
    path('student_pdf/', student_pdf, name='student_pdf'),
    path('student_csv/', student_csv, name='student_csv'),
    
    # path('login/', vi, name='login'),
    path('',include('auth_app.urls'))
    # path('',include('auth_app.urls'))
]
